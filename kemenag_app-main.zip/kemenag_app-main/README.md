# Layanan Kemenag Kota Sukabumi - Android App

Aplikasi Android untuk layanan Kementerian Agama Kota Sukabumi, dibangun dengan Kotlin dan Jetpack Compose.

## 🚀 Features

- **Authentication**
  - Login untuk admin dan user
  - Session management dengan SharedPreferences
  
- **Informasi Layanan**
  - Profil Kemenag
  - Informasi Haji dan Umrah
  - Bimbingan Masyarakat Islam (Bimas)
  - Pendidikan Agama Islam (PAI)
  - Sub Bagian Tata Usaha
  
- **Admin Features**
  - Edit informasi pada semua halaman
  - Update data langsung ke backend
  
- **Modern UI**
  - Material Design 3
  - Jetpack Compose
  - Dark/Light theme support

## 📋 Prerequisites

- Android Studio (latest version)
- JDK 17
- Android SDK API 29+ (Android 10+)
- Device atau emulator dengan minimum Android 10

## 🛠️ Installation

### 1. Clone Repository
```bash
git clone <repository-url>
cd android-kemenag
```

### 2. Open di Android Studio
- File → Open
- Pilih folder `android-kemenag`
- Tunggu Gradle sync selesai

### 3. Konfigurasi Backend URL

Edit `app/src/main/java/com/naufalm/layanankemenagkotasukabumi/data/ApiService.kt`:

```kotlin
.baseUrl("https://your-backend-url.vercel.app")
```

### 4. Build & Run
- Klik tombol Run (▶️)
- Atau tekan `Shift + F10`

## 📱 Build APK

### Debug APK
```bash
./gradlew assembleDebug
```
Output: `app/build/outputs/apk/debug/app-debug.apk`

### Release APK
```bash
./gradlew assembleRelease
```
Output: `app/build/outputs/apk/release/app-release.apk`

## 🔐 Default Admin Credentials

```
NIP: admin
Password: admin123
```

## 📂 Project Structure

```
android-kemenag/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/naufalm/layanankemenagkotasukabumi/
│   │   │   │   ├── MainActivity.kt
│   │   │   │   ├── components/          # Reusable UI components
│   │   │   │   ├── data/
│   │   │   │   │   ├── ApiService.kt    # Retrofit API service
│   │   │   │   │   ├── AuthManager.kt   # Session management
│   │   │   │   │   └── model/           # Data models
│   │   │   │   └── ui/
│   │   │   │       ├── screens/         # App screens
│   │   │   │       │   ├── login_screen/
│   │   │   │       │   ├── home_screen/
│   │   │   │       │   ├── bimas_screen/
│   │   │   │       │   ├── haji_screen/
│   │   │   │       │   ├── pai_screen/
│   │   │   │       │   └── subbag_tu_screen/
│   │   │   │       └── theme/           # App theme & colors
│   │   │   └── res/                     # Resources (drawable, font, etc)
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
├── gradle/
├── build.gradle.kts
└── settings.gradle.kts
```

## 🏗️ Tech Stack

- **Language**: Kotlin
- **UI Framework**: Jetpack Compose
- **Architecture**: MVVM
- **Navigation**: Compose Navigation
- **Network**: Retrofit + Gson
- **State Management**: ViewModel + StateFlow
- **Async**: Kotlin Coroutines

## 📦 Dependencies

- AndroidX Core KTX
- Jetpack Compose (Material3)
- Lifecycle & ViewModel
- Navigation Compose
- Retrofit 2
- Gson Converter
- Google Maps Compose

## 🎨 Design

- Material Design 3
- Plus Jakarta Sans font family
- Responsive layouts
- Adaptive themes

## 🔧 Configuration

### Minimum SDK: 29 (Android 10)
### Target SDK: 35 (Android 15)
### Compile SDK: 35

## 📝 How to Use

1. **Login**
   - Buka aplikasi
   - Masukkan NIP dan password
   - Untuk admin gunakan: `admin` / `admin123`

2. **Navigasi**
   - Pilih layanan dari home screen
   - View informasi detail
   - Admin dapat edit dengan klik icon edit (✏️)

3. **Edit Data (Admin Only)**
   - Klik icon edit
   - Ubah informasi
   - Klik "Simpan" untuk update
   - Klik "Batal" untuk membatalkan

## 🐛 Troubleshooting

### Gradle Sync Failed
```bash
./gradlew clean
./gradlew build --refresh-dependencies
```

### APK Install Failed
- Enable "Install from Unknown Sources"
- Enable USB Debugging
- Check minimum Android version (10+)

### API Connection Error
- Check backend URL di ApiService.kt
- Pastikan device/emulator punya koneksi internet
- Verifikasi backend sudah running

## 🚀 Deployment

### Google Play Store
1. Generate signed APK/Bundle
2. Create Play Console account
3. Upload APK/AAB
4. Fill store listing
5. Submit for review

## 📄 License

MIT

## 👥 Authors

Layanan Kemenag Kota Sukabumi Development Team
