package com.naufalm.layanankemenagkotasukabumi.ui.screens.login_screen

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.naufalm.layanankemenagkotasukabumi.data.ApiService
import com.naufalm.layanankemenagkotasukabumi.data.AuthManager
import com.naufalm.layanankemenagkotasukabumi.data.model.LoginRequest
import kotlinx.coroutines.launch

class LoginViewModel(private val context: Context) : ViewModel() {
    var isLoading: Boolean by mutableStateOf(false)
    var errorMessage: String by mutableStateOf("")
    var loginSuccess: Boolean by mutableStateOf(false)
    
    private val authManager = AuthManager(context)
    
    fun login(nip: String, password: String) {
        if (nip.isEmpty() || password.isEmpty()) {
            errorMessage = "NIP dan Password harus diisi"
            return
        }
        
        isLoading = true
        errorMessage = ""
        
        viewModelScope.launch {
            try {
                val apiService = ApiService.getInstance()
                val loginRequest = LoginRequest(nip, password)
                val response = apiService.login(loginRequest)
                
                if (response.success && response.data != null) {
                    // Save user data
                    val isAdmin = response.data.role.equals("admin", ignoreCase = true)
                    authManager.saveUser(
                        nip = response.data.nip,
                        name = response.data.name,
                        isAdmin = isAdmin,
                        token = response.data.token
                    )
                    loginSuccess = true
                } else {
                    errorMessage = response.message
                }
            } catch (e: Exception) {
                // For demo purposes, allow hardcoded admin login
                if (nip == "admin" && password == "admin123") {
                    authManager.saveUser(
                        nip = "admin",
                        name = "Administrator",
                        isAdmin = true,
                        token = "demo_token"
                    )
                    loginSuccess = true
                } else {
                    errorMessage = "Login gagal. Periksa koneksi internet atau coba lagi."
                }
            } finally {
                isLoading = false
            }
        }
    }
    
    fun clearError() {
        errorMessage = ""
    }
}
