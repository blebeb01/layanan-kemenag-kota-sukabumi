package com.naufalm.layanankemenagkotasukabumi.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val MintGreen01 = Color(0xFFB2FFE6)
val MintGreen02 = Color(0xFFE5FFF6)
val MintGreen03 = Color(0xFF578073)