package com.naufalm.layanankemenagkotasukabumi.ui.screens.subbag_tu_screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.naufalm.layanankemenagkotasukabumi.components.MyLargeTopAppBar
import com.naufalm.layanankemenagkotasukabumi.data.AuthManager
import com.naufalm.layanankemenagkotasukabumi.ui.theme.jakartaSansFontFamily

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubbagTuScreen(navController: NavController) {
    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior(rememberTopAppBarState())
    val context = LocalContext.current
    val authManager = remember { AuthManager(context) }
    val isAdmin = authManager.isAdmin()
    
    var editingIndex by remember { mutableStateOf<Int?>(null) }
    var editedText by remember { mutableStateOf("") }

    val viewModel: SubbagTuViewModel = viewModel()
    val infoSubbagTu = viewModel.infoSubbagTuResponse

    LaunchedEffect(Unit) {
        viewModel.getInfoSubbagTu()
    }

    Scaffold(
        modifier = Modifier
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            MyLargeTopAppBar(
                title = "Sub Tata Usaha",
                navigateBack = { navController.navigateUp() },
                scrollBehavior = scrollBehavior
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            infoSubbagTu.forEachIndexed { index, subbagTu ->
                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (editingIndex == index) {
                        // Edit mode
                        OutlinedTextField(
                            modifier = Modifier.fillMaxWidth(),
                            value = editedText,
                            onValueChange = { editedText = it },
                            label = { Text("Edit Informasi") },
                            minLines = 3
                        )
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    // TODO: Send editedText to backend
                                    // viewModel.updateSubbagTuInfo(index, editedText)
                                    editingIndex = null
                                }
                            ) {
                                Text("Simpan")
                            }

                            OutlinedButton(
                                onClick = {
                                    editingIndex = null
                                }
                            ) {
                                Text("Batal")
                            }
                        }
                    } else {
                        // Display mode
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                modifier = Modifier.weight(1f),
                                text = subbagTu,
                                fontFamily = jakartaSansFontFamily,
                                fontWeight = FontWeight.Normal,
                                color = Color.Black
                            )

                            if (isAdmin) {
                                IconButton(
                                    onClick = {
                                        editedText = subbagTu
                                        editingIndex = index
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit"
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}