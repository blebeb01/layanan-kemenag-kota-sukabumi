package com.naufalm.layanankemenagkotasukabumi.data.model

data class LoginRequest(
    val nip: String,
    val password: String
)

data class LoginResponse(
    val success: Boolean,
    val message: String,
    val data: UserData? = null
)

data class UserData(
    val nip: String,
    val name: String,
    val role: String, // "admin" or "user"
    val token: String? = null
)

data class User(
    val nip: String,
    val name: String,
    val isAdmin: Boolean
)
