package com.naufalm.layanankemenagkotasukabumi.data

import android.content.Context
import android.content.SharedPreferences
import com.naufalm.layanankemenagkotasukabumi.data.model.User

class AuthManager(context: Context) {
    private val prefs: SharedPreferences = 
        context.getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)
    
    companion object {
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_NIP = "nip"
        private const val KEY_NAME = "name"
        private const val KEY_IS_ADMIN = "is_admin"
        private const val KEY_TOKEN = "token"
    }
    
    fun saveUser(nip: String, name: String, isAdmin: Boolean, token: String? = null) {
        prefs.edit().apply {
            putBoolean(KEY_IS_LOGGED_IN, true)
            putString(KEY_NIP, nip)
            putString(KEY_NAME, name)
            putBoolean(KEY_IS_ADMIN, isAdmin)
            putString(KEY_TOKEN, token)
            apply()
        }
    }
    
    fun getUser(): User? {
        if (!isLoggedIn()) return null
        
        val nip = prefs.getString(KEY_NIP, "") ?: ""
        val name = prefs.getString(KEY_NAME, "") ?: ""
        val isAdmin = prefs.getBoolean(KEY_IS_ADMIN, false)
        
        return User(nip, name, isAdmin)
    }
    
    fun isLoggedIn(): Boolean {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    }
    
    fun isAdmin(): Boolean {
        return prefs.getBoolean(KEY_IS_ADMIN, false)
    }
    
    fun getToken(): String? {
        return prefs.getString(KEY_TOKEN, null)
    }
    
    fun logout() {
        prefs.edit().clear().apply()
    }
}
